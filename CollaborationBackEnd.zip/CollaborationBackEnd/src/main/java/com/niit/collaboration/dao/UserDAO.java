package com.niit.collaboration.dao;


import java.util.List;

import com.niit.collaboration.model.User;

public interface UserDAO {
	


		public List<User> list();

		public User getById(int id);

		public void saveOrUpdate(User user);
		
		public User getByName(String name);
		public User getByMail(String mail);

		public void delete(int id);
		
		
	}


