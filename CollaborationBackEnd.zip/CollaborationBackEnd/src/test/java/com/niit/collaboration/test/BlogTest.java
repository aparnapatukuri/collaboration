package com.niit.collaboration.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.collaboration.dao.BlogDAO;
import com.niit.collaboration.dao.ForumDAO;
import com.niit.collaboration.model.Blog;
import com.niit.collaboration.model.Forum;

public class BlogTest {
public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		
		context.scan("com.niit.collaboration");
		context.refresh();
		
		Blog b = (Blog)context.getBean("blog");
		
	  
	    b.setBlog_id(275);
	   
	    b.setTitle("apa");
	    b.setContent("gfhh");
	    b.setForum_date(8/18/2016);
	    b.setBlog_user("jhj");
	    
	    
	    
	    
	    
	    BlogDAO blogDAO = (BlogDAO)context.getBean("blogDAO");
	    blogDAO.saveOrUpdate(b);
		
		
	}



}
